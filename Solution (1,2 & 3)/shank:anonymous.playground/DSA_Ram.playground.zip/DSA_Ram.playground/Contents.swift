import UIKit

/*Challenge 1: Palindrome*/
func checkPalindromeNO(characters: String) -> Bool {
    if characters.count == 1 {
        return true
    } else if characters.count > 1 {
        let halfLengthOfCharacter = characters.count/2
        let firstHalf = String(characters.prefix(halfLengthOfCharacter))
        let secondHalf = String(characters.suffix(halfLengthOfCharacter).reversed())
        return firstHalf == secondHalf
    } else {
        return false
    }
}
let sampleCharacter = "A man, a plan, a cameo, Zena, Bird, Mocha ahcoM ,driB ,aneZ ,oemac a ,nalp a ,nam A"
if checkPalindromeNO(characters: sampleCharacter) {
    print("Palindrome")
} else {
    print("Not Palindrome")
}

/*Challenge 2: Largest product of two adjacent input*/
func adjacentElementsProduct(inputArray: [Int]) -> Int {
    var result = 0;
    for (index, _) in inputArray.enumerated() {
        if index > 0 {
            result = max(inputArray[index] * inputArray[index - 1], result)
        }
    }
    return result;
}

let sampleInput = [3, 6, -2, -5, 7, 3]
print(adjacentElementsProduct(inputArray: sampleInput))

/*Challenge 3: Find area of polygon in given input*/
func findAreaOfPolygon(n: Int) -> Int {
   n * (2*n - 1) - (n - 1)
}
let sampleInputPolygon = 3
print(findAreaOfPolygon(n: sampleInputPolygon))
